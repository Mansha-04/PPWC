#include <stdio.h>
int main(){
	float x,y;
	printf("Enter x:\n");
	scanf("%f",&x);
	printf("Enter y:\n");
	scanf("%f",&y);
	if(x>y){
		y=x-y;
	}
	else{
		y=y-x;
	}
	printf("Absolute difference of x and y is %d\n",(int)y);
}
	
		