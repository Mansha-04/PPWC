#include<stdio.h>
int main(){
	int n,i;
	int product=1;
	printf("Enter no. of items:\n");
	scanf("%d",&n);
	while(n<=0){
		printf("Enter valid no. of items:\n");
		scanf("%d",&n);
	}
	int arr[n];
	for(i=0;i<n;i++){
		printf("Enter item count for arr[%d]:",i);
		scanf("%d",&arr[i]);
		while(arr[i]<0){
			printf("Invalid item count.Enter item count for arr[%d]:",i);
			scanf("%d",&arr[i]);
		}
	}
	printf("\n");
	for(i=0;i<n;i++){
		if(arr[i]==0){
			continue;
		}
		else{
			product*=arr[i];
		}
	}
	printf("Product: %d\n",product);
}
		
		