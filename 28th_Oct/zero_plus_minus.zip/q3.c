#include<stdio.h>
int main(){
	int n,i;
	int zero_count=0;
	float minus_sum=0,plus_sum=0;
	printf("Enter no. of elements in array:\n");
	scanf("%d",&n);
	while(n<=0){
		printf("Enter valid no. of array elements:\n");
		scanf("%d",&n);
	}
	float arr[n];
	for(i=0;i<n;i++){
		printf("Enter arr[%d]:",i);
		scanf("%f",&arr[i]);
	}
	for(i=0;i<n;i++){
		if(arr[i]==0){
			zero_count++;
		}
		else if(arr[i]>0){
			plus_sum+=arr[i];
		}
		else{
			minus_sum+=arr[i];
		}
	}
	printf("Zero Count: %d\n",zero_count);
	printf("Minus Sum: %.2f\n",minus_sum);
	printf("Plus Sum: %.2f\n",plus_sum);
}
